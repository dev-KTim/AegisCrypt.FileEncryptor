﻿using System.Windows;

namespace FileEncryptor
{
    public partial class App : Application
    {
    }
}

